/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Nathasha
 */

//Logic for your address book
public class AddressBook {
    
    //read from file and create Address Book
    public static void initAddressBook(String fileName){
    
        /*TODO*/
    }
    
    //search details of the requested contact in the address book
    public static String search(String name){
	
        /*TODO*/
        return "Contact details of 'name'";
    }
    
}


