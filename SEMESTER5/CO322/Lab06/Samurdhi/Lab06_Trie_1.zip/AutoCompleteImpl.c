#include "AutoCompleteImpl.h"

TrieNode *createTrieNode() {
    TrieNode * node = (TrieNode*) malloc(sizeof(TrieNode));
    int i;
	for(i = 0; i < ALPHABET_SIZE; i++){
		node->children[i] = NULL;
	}
	return node;
}

void insert(TrieNode *root, const char *word) {

    if(root == NULL) return;
    TrieNode * current = root;
    

    int i, n = strlen(word);

    for(i = 0; i < n; i++){
        TrieNode * temp = current->children[word[i]- 'a'];
        if(temp != NULL){
            current = temp;
        }
        else{
            temp = createTrieNode();
            temp->label = word[i];
            temp->isEndOfWord = (i == n - 1);
            current->children[word[i] - 'a'] = temp;
            current = temp;
        }
    }
    
}

TrieNode *search(TrieNode *root, const char *word) {
    if(root == NULL) return NULL;
    TrieNode * current = root;

    int i;
    for(i = 0; i < strlen(word); i++){
        TrieNode * temp = current->children[word[i]- 'a'];
        if(temp == NULL){
            return NULL;
        }
        else{
            current = temp;
        }
    }

    return current;
}

void traverse(char prefix[], TrieNode *root, int pos) {

    if(root == NULL) return;

    if(root->isEndOfWord){
        int i;
        for(i = 0; i < pos; i++) printf("%c", prefix[i]);
        printf("\n");
    }

    int i;
    for(i = 0; i < ALPHABET_SIZE; i++){
        TrieNode * temp = root->children[i];
        if(temp != NULL){
            prefix[pos] = temp->label;
            traverse(prefix, temp, pos + 1);
        }
    }
}

void deleteTrie(TrieNode * root){
    if(root == NULL) return;

    int i = 0; 
    for (i = 0; i < 26; i++)
       deleteTrie(root->children[i]);

    free(root);
}